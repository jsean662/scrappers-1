# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# http://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class AcresItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    #pass
    platform = scrapy.Field()
    data_id = scrapy.Field()
    city = scrapy.Field()
    listing_date = scrapy.Field()
    txn_type = scrapy.Field()
    property_type = scrapy.Field()
    lat = scrapy.Field()
    lng = scrapy.Field()
    google_place_id = scrapy.Field()
    locality = scrapy.Field()
    building_name = scrapy.Field()
    config_type	= scrapy.Field()
    sqft = scrapy.Field()
    selling_price = scrapy.Field()
    monthly_rent = scrapy.Field()
    status = scrapy.Field()
    desc = scrapy.Field()
